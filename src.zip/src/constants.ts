export const MISSED_MODAL_ID_ERROR_MESSAGE = '[ERROR]: Modal ID is missing';
export const MISSED_MODAL_ROOT_ID_ERROR_MESSAGE =
  '[ERROR]: Modal root ID is missing';
