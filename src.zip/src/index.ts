export {
  default,
  default as ModalProvider,
  ModalProviderProps,
} from './modal-provider';
export { default as useModal, UseModalOptions } from './use-modal';
export * from './types';
export * from './modal-config';
export { getModal } from './modal-nexus';
